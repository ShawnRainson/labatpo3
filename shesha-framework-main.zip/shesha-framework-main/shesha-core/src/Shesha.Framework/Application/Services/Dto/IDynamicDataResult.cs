﻿namespace Shesha.Application.Services.Dto
{
    /// <summary>
    /// Dynamic data result
    /// </summary>
    public interface IDynamicDataResult
    {
    }
}
