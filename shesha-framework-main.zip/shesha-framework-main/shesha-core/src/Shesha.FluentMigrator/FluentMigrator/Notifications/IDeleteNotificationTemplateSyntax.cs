﻿namespace Shesha.FluentMigrator.Notifications
{
    public interface IDeleteNotificationTemplateSyntax
    {
    }
}
