﻿namespace Shesha
{
    /// <summary>
    /// DBMS type
    /// </summary>
    public enum DbmsType
    {
        NotSpecified,
        SQLServer,
        PostgreSQL
    }
}
