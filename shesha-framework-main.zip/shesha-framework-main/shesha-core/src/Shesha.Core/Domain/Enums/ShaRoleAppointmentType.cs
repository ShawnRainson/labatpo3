﻿namespace Shesha.Domain.Enums
{
    public enum ShaRoleAppointmentType
    {
        Person = 1,
        Post = 2,
        PostLevel = 3,
        Unit = 4
    }
}
