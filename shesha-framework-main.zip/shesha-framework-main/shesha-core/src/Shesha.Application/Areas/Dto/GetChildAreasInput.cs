﻿using System;

namespace Shesha.Areas.Dto
{
    public class GetChildAreasInput
    {
        public Guid? Id { get; set; }
    }
}
