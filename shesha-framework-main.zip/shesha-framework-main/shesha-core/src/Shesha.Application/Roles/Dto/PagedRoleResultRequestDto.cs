﻿using Abp.Application.Services.Dto;

namespace Shesha.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

