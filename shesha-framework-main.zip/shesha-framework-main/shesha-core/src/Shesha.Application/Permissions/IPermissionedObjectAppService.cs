﻿using System;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Shesha.Permissions;

namespace Shesha.Permissions
{
    /// <summary>
    /// Person Application Service
    /// </summary>
    public interface IPermissionedObjectAppService
    {
    }
}
