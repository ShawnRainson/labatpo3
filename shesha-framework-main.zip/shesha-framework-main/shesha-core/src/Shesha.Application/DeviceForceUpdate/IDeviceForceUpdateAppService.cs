﻿using Abp.Application.Services;
using Shesha.DeviceForceUpdate.Dto;
using System;
using System.Collections.Generic;
using System.Text;

namespace Shesha.DeviceForceUpdate
{
    public interface IDeviceForceUpdateAppService 
    {
    }
}
