﻿namespace Shesha
{
    public interface IDynamicCrudAppService<TEntity, TDynamicDto, TPrimaryKey>
    {
        
    }
}