﻿using Shesha.Settings;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Shesha.Otp.Configuration
{
    /// <summary>
    /// One time pin Settings
    /// </summary>
    [Category("Security")]
    public interface IOtpSettings: ISettingAccessors
    {
        /// <summary>
        ///
        /// </summary>
        [Display(Name = "One-Time-Pins")]
        [Setting(OtpSettingsNames.OneTimePinSettings, editorFormName:"one-time-pin-settings")]
        ISettingAccessor<OtpSettings> OneTimePins { get; }
    }
}
