﻿namespace Shesha.Otp.Configuration
{
    public static class OtpSettingsNames
    {
        public const string OneTimePinSettings = "Shesha.Otp";
    }
}
