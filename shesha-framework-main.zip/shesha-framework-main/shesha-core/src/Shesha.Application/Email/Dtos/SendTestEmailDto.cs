﻿namespace Shesha.Email.Dtos
{
    /// <summary>
    /// 
    /// </summary>
    public class SendTestEmailDto
    {
        public bool Success { get; set; }
    }
}
