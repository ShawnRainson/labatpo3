﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Shesha.Domain;


namespace Shesha.EntityHistory
{
    public interface IEntityHistoryAppService : IApplicationService
    {
        
    }
}