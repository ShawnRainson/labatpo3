﻿namespace Shesha.ConfigurationItems.Dtos
{
    /// <summary>
    /// Results of configuration items import
    /// </summary>
    public class PackageImportResult
    {
    }
}
