﻿namespace Shesha.Elmah
{
    public static class DBConstants
    {
        public const string Schema = "elmah";
        public const string ErrorsTable = "errors";
        public const string ErrorRefsTable = "error_refs";
    }
}
