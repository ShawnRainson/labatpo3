shesha-core
========================

[![docs](https://readthedocs.org/projects/shesha-core/badge/?version=latest)](https://shesha-core.readthedocs.io/en/latest/?badge=latest)

## License

Shesha and the various shesha community components and services are available under the [GPL-3.0 license](https://opensource.org/licenses/GPL-3.0). Shesha also includes external libraries that are available under a variety of licenses. See [LICENSE](https://github.com/boxfusion/shesha-core/blob/HEAD/LICENSE) for the full license text

Commit Build
